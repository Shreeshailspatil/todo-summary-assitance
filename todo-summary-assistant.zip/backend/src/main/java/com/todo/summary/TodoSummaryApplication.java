package com.todo.summary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoSummaryApplication {
    public static void main(String[] args) {
        SpringApplication.run(TodoSummaryApplication.class, args);
    }
}